<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz1</title>
    <link rel="stylesheet" href="child_quiz1.css"/>
</head>
<body>
    

    
    <div class="nav-container">
      <div class="logo">
        <img src="images/logo.jpg" align="right" height="80px" width="80px" >
    </div> 
    <a  href="dashboard.html">
      <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button>
    </a>
     
     
            <nav>

         
              <div class="icon-bar">
                <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
               
              </div>  
            </nav>
           
           

       
       
        
        <h1 class="title" align="center">Quiz</h1>

        
       
             
      <nav>
          
      
          
        <input type="button" class="button active" value="Grade">
        <a href="child_quiz2.php">
          <input type="button" class="button " value="Chapter"></a>
       
        
        <input type="button" class="button" value="Score">
       
        
       
    </nav>
         <br>   <br>      
        <nav>
            <a href="child_quiz2.php"><button class="button1"> <img src="images/btn 1child.png" align="left">
              <h2 ><span class="multicolortext">Grade 1</span></h2><br><br><br><p style="color:rgb(124, 120, 120);
           size: 10px; margin-top: 0%;"><br><br><br><br><br><br><br><br><br>
           <br><br><br><br><br><br>You completed 75%.</p><br><br><br><br><br><br><br><br><br> 
           <div class="progress1">
              <div class="progress1-value"></div>
            </div>
          </button>
           </a>
            
           <button class="button1"><img src="images/btn 1child.png" align="left">
            <h2 ><span class="multicolortext">Grade 2</span></h2><br><br><br><p style="color:rgb(124, 120, 120);
            size: 10px; margin-top: 0%;"><br><br><br><br><br><br><br><br><br>
             <br><br><br><br><br><br>You completed 25%.</p><br><br><br><br><br><br><br><br><br>
             <div class="progress2">
                <div class="progress2-value"></div>
              </div>
            </button>
              
            <button class="button1"><img src="images/btn 1child.png" align="left">
                <h2 ><span class="multicolortext">Grade 3</span></h2><br><br><br><p style="color:rgb(124, 120, 120);
                size: 10px; margin-top: 0%;"><br><br><br><br><br><br><br><br><br>
             <br><br><br><br><br><br>You completed 86%.</p><br><br><br><br><br><br><br><br><br>
             <div class="progress3">
                <div class="progress3-value"></div>
              </div>
            </button>
             
        </nav>

        
       
        <nav>
            
        
            <button class="button2"align="right"><img src="images/btn 1child.png" align="left"><br><br>
                <h2 ><span class="multicolortext">Grade 4</span></h2><br><br><br><p style="color:rgb(124, 120, 120);
                size: 10px; margin-top: 0%;"><br><br><br><br><br><br><br><br><br>
             <br><br><br><br><br><br>You completed 42%.</p><br><br><br><br><br><br><br><br><br>
             <div class="progress4">
                <div class="progress4-value"></div>
              </div>
            </button>
             
                
            <img src="images/girl.png" align="center" height="200px" width="250px"/>
           
            
              <button class="button4"><img src="images/btn 1child.png" align="left"><br><br>
                <h2 ><span class="multicolortext">Grade 5</span></h2><br><br><br><p style="color:rgb(124, 120, 120);
                size: 10px; margin-top: 0%;"><br><br><br><br><br><br><br><br><br>
             <br><br><br><br><br><br>You completed 68%.</p><br><br><br><br><br><br><br><br><br>
             <div class="progress5">
                <div class="progress5-value"></div>
              </div>
            </button>
             
                 
                
            

            
        </nav>

    </div>
    <br>  <br> <br>  <br> <br>  <br> <br>  <br> <br>  
    <br>  <br> <br>  <br> <br>  <br> <br>  <br>
    <br>  <br> <br>  <br> <br>   <br> <br>   <br>  <br> 
    <br>   <br>  
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>           

</body>
</html>