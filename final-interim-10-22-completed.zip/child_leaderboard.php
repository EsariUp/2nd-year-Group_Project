<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_leaderboard.css">
    <title>Learderboard</title>
</head>
<body>
    <a href="child_dashboard.php">
        <button class="btn1"><img src="images/back.png" height="80px" width="60px"></button> </a>
       
        <img src="images/logo.jpg" align="right" height="80px" width="80px">
        <h1 class="title" align="center">Leaderboard</h1>
    <div class="score-nav">
        
        <!-- <img src="images/star.png" class="st1" width="80px" height="80px">
        <br><br> <img src="images/rib.png" class="st2" width="80px" height="80px">
        <img src="images/star.png" class="st4" width="80px" height="80px">
        <br><br> <img src="images/rib.png" class="st3" width="80px" height="80px"> -->
        <br>  <br>  <br>  <br>  <br><br>  <br><br>  <br>  
        <div class="child_1">
           
            <img src="images/girls3.png" class="boy1" align="center" height="80px" width="80px">
            <h4>Shaji Noor</h4>
            <h2>1st Runners Up</h2>
            <img src="images/stars2.png" class="gold" align="center" height="100px" width="90px">
            <p class="score">Score</p>
            <p class="mark">42/<small>50</small></p>
        </div>
        <div class="child_2">
            <img src="images/1boy.png" class="boy1" align="center" height="80px" width="80px">
            <h4>Shane Perera</h4>
            <h2>Champion</h2>
            <img src="images/gold.png" class="gold" align="center" height="90px" width="90px">
            <p class="score">Score</p>
            <p class="mark">45/<small>50</small></p>
        </div>
        <div class="child_3" id="div3">
           
            <img src="images/girls.png" class="boy1" align="center" height="80px" width="70px">
            <h4>Windy Fernando</h4>
            <h2>2nd Runners Up</h2>
            <img src="images/stars2.png" class="gold" align="center" height="100px" width="90px">
            <p class="score">Score</p>
            <p class="mark">38/<small>50</small></p>
        </div>
        <div class="child_4" id="div4">
           
            <!-- <img src="images/1boy.png" class="boy1" align="center" height="10px" width="10px"> -->
            <!-- <h4>Shane Perera</h4> -->
            <h5>Yours Current Rank</h5>
            <h6>7th Place</h6>
            <p class="s">Score 45/<small>50</small></p> 
            
            <!-- <img src="images/gold.png" class="gold" align="center" height="10px" width="10px"> -->
            <!-- <p >Score</p>
          
           
        </div>
      
    </div>
    
    


    
</body>
</html>