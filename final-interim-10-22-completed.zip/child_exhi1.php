<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_exhi1.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <title>1st Lesson</title>
</head>
<body>
    
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_dashboard.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
         <br>  
         <br>  
         <br>  
        
          
          <h1 class="title" align="center"> Our Creations
          </h1>
      
       
          <br>  <br>  <br>  <br>
         
         <br>  <br>  
<div class="head">
    <h2>Grade One</h2> <br>
    <div class="c-one">
      <div class="container">
        <input type="file" id="file-input" accept="image/png, image/jpeg" onchange="preview()" multiple>
        <label for="file-input">
            <i class="fas fa-upload"></i> &nbsp; Choose A Photo
        </label>
        <p id="num-of-files">No Files Chosen</p>
        <div id="images"></div>
    </div>
      
    </div>
    <br><br><br>
    <h2>Grade Two</h2> <br>
    <div class="c-one">
      <div class="container">
        <input type="file" id="file-input" accept="image/png, image/jpeg" onchange="preview()" multiple>
        <label for="file-input">
            <i class="fas fa-upload"></i> &nbsp; Choose A Photo
        </label>
        <p id="num-of-files">No Files Chosen</p>
        <div id="images"></div>
    </div> 
    </div>
    <br><br><br>
    <h2>Grade Three</h2> <br>
    <div class="container">
      <input type="file" id="file-input" accept="image/png, image/jpeg" onchange="preview()" multiple>
      <label for="file-input">
          <i class="fas fa-upload"></i> &nbsp; Choose A Photo
      </label>
      <p id="num-of-files">No Files Chosen</p>
      <div id="images"></div>
  </div>
    </div>
    <br><br><br>
    <h2>Grade Four</h2> <br>
    <div class="c-one">
      <div class="container">
        <input type="file" id="file-input" accept="image/png, image/jpeg" onchange="preview()" multiple>
        <label for="file-input">
            <i class="fas fa-upload"></i> &nbsp; Choose A Photo
        </label>
        <p id="num-of-files">No Files Chosen</p>
        <div id="images"></div>
    </div>
    </div>
    <br><br><br>
    <h2>Grade Five</h2> <br>
    <div class="container">
      <input type="file" id="file-input" accept="image/png, image/jpeg" onchange="preview()" multiple>
      <label for="file-input">
          <i class="fas fa-upload"></i> &nbsp; Choose A Photo
      </label>
      <p id="num-of-files">No Files Chosen</p>
      <div id="images"></div>
  </div>
    </div>
</div>
    
  <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> 
  <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> 
  <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br> <br>   <br>   <br>   <br>   <br>   <br>  
  <br>   <br>   <br>   <br>   <br>   <br>

   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div> 
<script>
    $(document).ready(function(){
      $('.content').click(function(){
        $('.content').toggleClass("heart-active")
        $('.text').toggleClass("heart-active")
        $('.numb').toggleClass("heart-active")
        $('.heart').toggleClass("heart-active")
      });
    });

    let fileInput = document.getElementById("file-input");
let imageContainer = document.getElementById("images");
let numOfFiles = document.getElementById("num-of-files");

function preview(){
    imageContainer.innerHTML = "";
    numOfFiles.textContent = `${fileInput.files.length} Files Selected`;

    for(i of fileInput.files){
        let reader = new FileReader();
        let figure = document.createElement("figure");
        let figCap = document.createElement("figcaption");
        figCap.innerText = i.name;
        figure.appendChild(figCap);
        reader.onload=()=>{
            let img = document.createElement("img");
            img.setAttribute("src",reader.result);
            figure.insertBefore(img,figCap);
        }
        imageContainer.appendChild(figure);
        reader.readAsDataURL(i);
    }
}
  </script>
</body>
</html>