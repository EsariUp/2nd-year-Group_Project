<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_a3.css">
    <title>Poems</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_aes.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> Poems-Aesthetic
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
           
            <iframe src=" https://youtube.com/embed/6R49IH6Id3c" class ="video" frameborder="0"></iframe>
         <br> <br> <br>
          <button class="namebutton"><span>
           Parts of a Poem
          </span>
           
          </button>
         
        </div>
        <div class="button1">
         
          <iframe src="https://youtube.com/embed/yCCrS_jynbg" class="video" frameborder="0"></iframe>
       <br> <br> <br>
        <button class="namebutton"><span>
         "All of Me"
        </span>
         
        </button>
        
      </div>
      <div class="button1">
       
        <iframe src="https://youtube.com/embed/bnpfjEHF-NU"   class="video" frameborder="0"></iframe>
     <br> <br> <br>
      <button class="namebutton"><span>
        "Twinkle Twinkle Little Star"
      </span>
       
      </button>
      
    </div>
    <br> <br> <br>

    <div class="button1">
     
      <iframe src="https://youtube.com/embed/l6GDiAXGBII"   class="video" frameborder="0"></iframe>
   <br> <br> <br>
    <button class="namebutton"><span>
    "My Body"
    </span>
     
    </button>
    
  </div>
  <div class="button1">
   
    <iframe src="https://youtube.com/embed/TRuz6fadjEw"   class="video" frameborder="0"></iframe>
 <br> <br> <br>
  <button class="namebutton"><span>
   "Once I laughed my socks off"
  </span>
   
  </button>
  
</div>
<div class="button1">
  
  <iframe src="https://youtube.com/embed/iDG2-bxpno0"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
 "The worm that wouldn't wiggle"
</span>
 
</button>

</div>
     
    </div>
    <br>  
    
    
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>