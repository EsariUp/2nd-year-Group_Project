<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_m2.css">
    <title>Document</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_maths.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                <a class="active" href="child_dashboard.php"><img src="images/home.png" height="30px" width="30px"/></a> 
      <a href="child_profile.php"><img src="images/profile1.png" height="30px" width="30px"/></a> 
      <a href="child>discussion.php"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> Mathematical Methods-Maths
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
           
            <iframe src=" https://youtube.com/embed/2sghJbCPnyw" class="video" frameborder="0"></iframe>
         <br> <br> <br>
          <button class="namebutton"><span>
            Identification of Numbers
          </span>
           
          </button>
         
        </div>
        <div class="button1">
         
          <iframe src="https://youtube.com/embed/VScM8Z8Jls0"  class="video" frameborder="0"></iframe>
       <br> <br> <br>
        <button class="namebutton"><span>
          Addition
        </span>
         
        </button>
        
      </div>
      <div class="button1">
       
        <iframe src="https://youtube.com/embed/YLPbduEc4sA" class="video" frameborder="0"></iframe>
     <br> <br> <br>
      <button class="namebutton"><span>
        Substraction
      </span>
       
      </button>
      
    </div>
    <br> <br> <br>

    <div class="button1">
     
      <iframe src="https://youtube.com/embed/CFDCG1b4ahk"  class="video" frameborder="0"></iframe>
   <br> <br> <br>
    <button class="namebutton"><span>
     Multiplication
    </span>
     
    </button>
    
  </div>
  <div class="button1">
   
    <iframe src="https://youtube.com/embed/n3h5zlHP5mQ"  class="video" frameborder="0"></iframe>
 <br> <br> <br>
  <button class="namebutton"><span>
    Division
  </span>
   
  </button>
  
</div>
<div class="button1">
  
  <iframe src="https://youtube.com/embed/n_1_wOp5k4k"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Mathematical Methods
</span>
 
</button>

</div>
     
    </div>
    <br>  
    
    
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>