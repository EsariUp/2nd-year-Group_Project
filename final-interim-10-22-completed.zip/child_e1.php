<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_s1.css">
    <title>1st Lesson</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_sinhala.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="child_dashboard.php"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="child_profile.php"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="child_discussion.php"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> English
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
            <!-- <iframe class="video"  src="https://www.youtube.com/
            embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
             allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
            gyroscope; picture-in-picture" allowfullscreen></iframe> -->
            <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
            <iframe src="images/alphabet.pdf#toolbar=0" class="pdf" >
    </iframe>
         <br> <br>
          <button class="namebutton1"><span>
           English Alphabet
            
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <!-- <iframe class="video"  src="https://www.youtube.com/
          embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
           allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
          gyroscope; picture-in-picture" allowfullscreen></iframe> -->
          <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
          <iframe src="images/Vocabulary.pdf#toolbar=0" class="pdf" >
  </iframe>
       <br> <br>
        <button class="namebutton1"><span>
          Vocabulary
          
        </span>
         
        </button>
       
      </div>
      <div class="button1">
        <!-- <iframe class="video"  src="https://www.youtube.com/
        embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
         allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
        gyroscope; picture-in-picture" allowfullscreen></iframe> -->
        <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
        <iframe src="images/Nouns.pdf#toolbar=0" class="pdf" >
</iframe>
     <br> <br>
      <button class="namebutton1"><span>
       Nouns

        
      </span>
       
      </button>
     
    </div>
 <br><br><br><br> <br>
 <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/verbs.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton1"><span>
   Verbs
    
  
</span>
 
</button>

</div>  <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/Writing1.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton1"><span>
   Writing
</span>
 
</button>

</div>  
<div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/Comprehension.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton1"><span>
  Comprehension
</span>
 
</button>

</div>  
    </div>
    <br>  <br> <br> <br>
    <div class="chapterButtons">
        <div class="button1">
           
            <iframe src="  https://youtube.com/embed/k-1dMgvAJMU"  class="video" frameborder="0"></iframe>
         <br> <br> <br>
          <button class="namebutton"><span>
            Aphabet
          </span>
           
          </button>
         
        </div>
        <div class="button1">
         
          <iframe src="https://youtube.com/embed/ybt2jhCQ3lA" class="video" frameborder="0"></iframe>
       <br> <br> <br>
        <button class="namebutton"><span>
           Vocabulary
        </span>
         
        </button>
        
      </div>
      <div class="button1">
       
        <iframe src="https://youtube.com/embed/xh31SRczFNk" class="video" frameborder="0"></iframe>
     <br> <br> <br>
      <button class="namebutton"><span>
       Nouns
      </span>
       
      </button>
      
    </div>
    <br> <br> <br>

    <div class="button1">
     
      <iframe src="https://youtube.com/embed/8Ha_uBAYl_M"   class="video" frameborder="0"></iframe>
   <br> <br> <br>
    <button class="namebutton"><span>
        Verbs
    </span>
     
    </button>
    
  </div>
  <div class="button1">
   
    <iframe src="https://youtube.com/embed/Sw2KZki-eaA"   class="video" frameborder="0"></iframe>
 <br> <br> <br>
  <button class="namebutton"><span>
   Writing
  </span>
   
  </button>
  
</div>
<div class="button1">
  
  <iframe src="https://youtube.com/embed/Uc2EESjOVGo "  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Comprehension

</span>
 
</button>

</div>
    
  <br>  
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>