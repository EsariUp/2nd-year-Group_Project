<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_s1.css">
    <title>1st Lesson</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_sinhala.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="child_dashboard.php"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="child_profile.php"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="child_discussion.php"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> සිං‍හල - 1 පාඩම
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
            <!-- <iframe class="video"  src="https://www.youtube.com/
            embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
             allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
            gyroscope; picture-in-picture" allowfullscreen></iframe> -->
            <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
            <iframe src="images/අකුරු.pdf#toolbar=0" class="pdf" >
    </iframe>
         <br> <br>
          <button class="namebutton1"><span>
            සිංහල අකුරු
            
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <!-- <iframe class="video"  src="https://www.youtube.com/
          embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
           allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
          gyroscope; picture-in-picture" allowfullscreen></iframe> -->
          <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
          <iframe src="images/pillam.pdf#toolbar=0" class="pdf" >
  </iframe>
       <br> <br>
        <button class="namebutton1"><span>
            පිල්ලම් පාඩම

          
        </span>
         
        </button>
       
      </div>
      <div class="button1">
        <!-- <iframe class="video"  src="https://www.youtube.com/
        embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
         allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
        gyroscope; picture-in-picture" allowfullscreen></iframe> -->
        <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
        <iframe src="images/therawili.pdf#toolbar=0" class="pdf" >
</iframe>
     <br> <br>
      <button class="namebutton1"><span>
        සිංහල තේරවිලි

        
      </span>
       
      </button>
     
    </div>
 <br><br><br><br> <br>
 <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/janakavi.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton1"><span>
    ජන කවි
    
  
</span>
 
</button>

</div>  <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/rabanpada.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton1"><span>
    රබන් පද
</span>
 
</button>

</div>  
    </div>
    <br>  <br> <br> <br>
    <div class="chapterButtons">
        <div class="button1">
           
            <iframe src="  https://youtube.com/embed/zss6Slqh0Bg"  class="video" frameborder="0"></iframe>
         <br> <br> <br>
          <button class="namebutton"><span>
            සිංහල අකුරු I
          </span>
           
          </button>
         
        </div>
        <div class="button1">
         
          <iframe src="https://youtube.com/embed/ImxteMgxW_s"  class="video" frameborder="0"></iframe>
       <br> <br> <br>
        <button class="namebutton"><span>
            සිංහල තේරවිලි
        </span>
         
        </button>
        
      </div>
      <div class="button1">
       
        <iframe src="https://youtube.com/embed/3p_5DEz6O6Y"  class="video" frameborder="0"></iframe>
     <br> <br> <br>
      <button class="namebutton"><span>
        ජන කවි
      </span>
       
      </button>
      
    </div>
    <br> <br> <br>

    <div class="button1">
     
      <iframe src="https://youtube.com/embed/WdAz6EE2Y7Y"  class="video" frameborder="0"></iframe>
   <br> <br> <br>
    <button class="namebutton"><span>
        රබන් පද
    </span>
     
    </button>
    
  </div>
  <div class="button1">
   
    <iframe src="https://youtube.com/embed/LfWU52Mxd6o"  class="video" frameborder="0"></iframe>
 <br> <br> <br>
  <button class="namebutton"><span>
    සිංහල අකුරු II
  </span>
   
  </button>
  
</div>
<div class="button1">
  
  <iframe src="https://youtube.com/embed/0eoVtAqojgU"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
    පිල්ලම් පාඩම

</span>
 
</button>

</div>
    
  <br>  
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>