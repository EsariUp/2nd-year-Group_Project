<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="child_Payment.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
  <div class="nav-container">
    <div class="logo">
      <img src="images/logo.jpg" align="right" height="80px" width="80px" >
  </div> 
  <a href="skole_welcome_page.html"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
   <br><br><br><br>
  <div class="wrapper">
    <div class="table basic">
      <div class="price-section">
        <div class="price-area">
          <div class="inner-area">
            <span class="text">Rs.</span>
            <span class="price">4000</span>
          </div>
        </div>
      </div>
      <div class="package-name"></div>
      <ul class="features">
        <li>
          <span class="list-name">English, Mathematics, Sinhala, Aesthetic</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Video lessons, PDFS, Quizes, Discussion Forums</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Chat Area</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Drawing Board, Exhibition</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
      </ul>
      <div class="btn"><button>Subscribe</button></div>
    </div>



    <div class="table premium">
    <!-- //  <div class="ribbon"><span>Recommend</span></div> -->
      <div class="price-section">
        <div class="price-area">
          <div class="inner-area">
            <span class="text">Rs.</span>
            <span class="price">4500</span>
          </div>
        </div>
      </div>
      <div class="package-name"></div>
      <ul class="features">
        <li>
          <span class="list-name">English, Mathematics, Sinhala, Aesthetic</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Video lessons, PDFS, Quizes, Discussion Forums</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Chat Area</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Drawing Board, Exhibition</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
      </ul>
      <div class="btn"><button>Subscribe</button></div>
    </div>
    <div class="table ultimate">
      <div class="price-section">
        <div class="price-area">
          <div class="inner-area">
            <span class="text">Rs.</span>
            <span class="price">5000</span>
          </div>
        </div>
      </div>
      <div class="package-name"></div>
      <ul class="features">
        <li>
          <span class="list-name">English, Mathematics, Sinhala, Aesthetic </span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Video lessons, PDFS, Quizes, Discussion Forums</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Chat Area</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
        <li>
          <span class="list-name">Drawing Board, Exhibition</span>
          <span class="icon check"><i class="fas fa-check"></i></span>
        </li>
      </ul>
      <div class="btn"><button>Subscribe</button></div>
    </div>
  </div>

</body>
</html>
