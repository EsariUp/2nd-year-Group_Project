<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_maths.css"/>
    <title>Maths</title>
</head>
<body>
  <div class="main-bg">
    <img src="images/logo.jpg" align="right" height="80px" width="80px">

  <div class="icon-bar">
  <a class="active" href="child_dashboard.php"><img src="images/home.png" height="30px" width="30px"/></a> 
      <a href="child_profile.php"><img src="images/profile1.png" height="30px" width="30px"/></a> 
      <a href="child>discussion.php"><img src="images/notifications.png" height="30px" width="30px"/></a> 
    </div>  
    <div class="sidebar1">
        
        </div>
        <h1 class="title" align="center">Maths is Fun</h1>
        <div class="topnav">
           
           
           </div>
    <!-- <div class="sidebar">
      <a href="child_subject.php">
        <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button>
      </a>
        
       <br><br><br><br><br><br>
       <ul>
           
        <li><a href="#quiz"><img src="" height="40px">Dashboard</a></li>
        <li><a href="#mycourse"><img src="" height="40px">My Course</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Maths</a></li>
        <li><a href="#mycourse"><img src="" height="40px">English</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Sinhala</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Aesthetic</a></li>
        <li><a href="#logout"><img src="" height="40px">Quiz</a></li>
        <li><a href="#payment"><img src="" height="40px">Payment</a></li>
        <li><a href="#logout"><img src="" height="40px">Logout</a></li>
      </ul>
       
    </div>   -->

    <div class="grid-container">
  <div class="sidebar">
  
        
       
  <a href="child_dashboard.php">Dashboard</a>
  <a href="child_maths.php">Mathematics</a>
  <a href="child_sinhala.php">Sinhala</a>
  <a href="child_eng.php">English</a>
  <a href="child_aes.php">Aesthetic</a>
 
  <a href="child_quiz1.php">Quiz</a>
  <a href="child_profile.php">Profile</a>
  
  <a href="logout.php?logout=true">Logout</a>
   
  </div>
   
       
    <div class="imgbox"> 
      <a href="teacher_profile.php">  
    <button class="teacher_button">Meet Your Teacher</button></a><br><br><br><br><br><br>
        <img class="center-fit" src='images/mbg.png'>
       <div class="container1">
        <div class="subnav1">
            <p> Try with Videos</p>
            <!-- <img src="images/shape.png" height="60px" width="80px"> -->
      <a href="child_m2.php">
        <button class="btn2">Start</button></a>
 
     </div>
     
    
 <div class="subnav1">
  <p>Try with Pdfs</p>
  <!-- <img src="images/meth.png" height="50px" width="70px"> -->
  <a href="child_m1.php">   
  <button class="btn2">Start</button></a>

</div>
<br>
<!-- <div class="subnav2">
    <p>Measurements</p>
    <img src="images/measure.png" height="60px" width="80px">
      
    <button class="btn2">Start</button>
  
  </div> -->
  

     
   </div>
   <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>           

     
         </div>

    
</body>
</html>