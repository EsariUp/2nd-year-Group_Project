<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_a2.css"/>
    <title>Quiz2</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_aes.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="upload.php" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> Karoake
          </h1>
      
       
          <br>  <br>  <br>  <br>
          <h3 class="sub-topic">Recorded Videos/Youtube Videos</h3>
      <div class="chapterButtons">
  
       
      
    
        <a href="upload.php" class="btn">Upload a new video</a>

        <div class="row">
            <?php
            include("db.php");
            $q="SELECT * FROM video";
            $query=mysqli_query($conn,$q);

            while($row=mysqli_fetch_array($query)){
                $name = $row['name'];
                ?>
            <div class="col">
                <video id="myVideo" width="25%" class="video"  controls>
                    <source src="<?php echo 'upload/'.$name;?>">
                </video>
                
            </div>
           <?php  }
           ?>
          
          
          </div>
        </div>
    </div>
        <br> <br> <br>
        <!-- <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
        <div class="button1">
          <video class="video" width="320" height="240" controls>
            <source src=”images/shapes_fpr_1.mp4” type=video/ogg>
            <source src="images/shapes_fpr_1.mp4" type=video/mp4>
          </video>
         
        <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
        <div class="button1">
          <video class="video" width="320" height="240" controls>
            <source src=”images/Grade_2_Maths_English_Medium_Session_03.mp4” type=video/ogg>
            <source src="images/Grade_2_Maths_English_Medium_Session_03.mp4" type=video/mp4>
          </video>
          
        <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
        <br><br><br><br>
        <div class="button1">
          <video class="video" width="320" height="240" controls>
            <source src=”images/Grade_1_English_Medium_Maths_Session_01.mp4” type=video/ogg>
            <source src="images/Grade_1_English_Medium_Maths_Session_01.mp4" type=video/mp4>
          </video>
         
        <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
        <div class="button1">
          <video class="video" width="320" height="240" controls>
            <source src=”images/Grade_2_English_Medium_Maths_Session_01.mp4” type=video/ogg>
            <source src="images/Grade_2_English_Medium_Maths_Session_01.mp4" type=video/mp4>
          </video>
     
        <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
        <div class="button1">
  
          <iframe src=" https://youtube.com/embed/4Lyx7zbmbX4"  class="video" frameborder="0"></iframe>
        <br> <br> <br>
        <button class="namebutton"><span>
          Mathematical Methods
        </span>
         
        </button>
        
        </div>
        <br><br><br><br>

        <div class="button1">
          <video class="video" width="320" height="240" controls>
            <source src=”images/maths_addition.mp4” type=video/ogg>
            <source src="images/maths_addition.mp4" type=video/mp4>
          </video>
         
        <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part VI
        </span>
         
        </button>
        
        </div>
<div class="button1"> 
  
  <iframe src=" https://youtube.com/embed/4YEnxbTllcs"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Mathematical Methods
</span>
 
</button>

</div>
<div class="button1">
  <video class="video" width="320" height="240" controls>
    <source src=”images/shapes_fpr_1.mp4” type=video/ogg>
    <source src="images/shapes_fpr_1.mp4" type=video/mp4>
  </video>
  
<br> <br> <br>
<button class="namebutton"><span>
  Shapes - Part VI
</span>
 
</button>

</div>

<br><br><br><br>
<div class="button1">
  
  <iframe src="https://youtube.com/embed/n_1_wOp5k4k"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Mathematical Methods
</span>
 
</button>

</div>
<div class="button1">
  
  <iframe src=" https://youtube.com/embed/Hwr4gEHepOo"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Mathematical Methods
</span>
 
</button>

</div>

<div class="button1">
  <video class="video" width="320" height="240" controls>
    <source src=”images/Grade_2_Maths_English_Medium_Session_03.mp4” type=video/ogg>
    <source src="images/Grade_2_Maths_English_Medium_Session_03.mp4" type=video/mp4>
  </video>

<br> <br> <br>
<button class="namebutton"><span>
  Shapes - Part VI
</span>
 
</button>

</div>
     
    </div>
              -->
           
           
                             
     </div>

   <br><br> <br><br> <br><br> <br><br> <br><br>
   <br><br> <br><br> <br><br> <br><br> <br><br>
   <br><br> <br><br> <br><br> <br><br> <br><br>
   <br><br> <br><br> <br><br> <br><br> <br><br>
   <br><br> <br><br> <br><br> <br><br> <br><br>
   <br><br> <br><br> <br><br> <br><br> <br><br>
   <hr style="color: blue; ">          
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>