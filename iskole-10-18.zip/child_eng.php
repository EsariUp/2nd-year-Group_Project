<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_eng.css"/>
    <title>English</title>
</head>

<body>
  <div class="main-bg">
    <img src="images/logo.jpg" align="right" height="80px" width="80px">

  <div class="icon-bar">
      <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
      <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
      <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
     
    </div>  
    <!-- <div class="sidebar">
      <a href="child_subject.php">
        <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button>
      </a>
       
       <br><br><br><br><br><br>
       <ul>
           
        <li><a href="#quiz"><img src="" height="40px">Dashboard</a></li>
        <li><a href="#mycourse"><img src="" height="40px">My Course</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Maths</a></li>
        <li><a href="#mycourse"><img src="" height="40px">English</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Sinhala</a></li>
        <li><a href="#mycourse"><img src="" height="40px">Aesthetic</a></li>
        <li><a href="#logout"><img src="" height="40px">Logout</a></li>
        <li><a href="#payment"><img src="" height="40px">Payment</a></li>
        <li><a href="#logout"><img src="" height="40px">Logout</a></li>
      </ul>
       
    </div> -->
    <div class="grid-container">
  <div class="sidebar">
  
        
       
  <a href="child_dashboard.php">Dashboard</a>
  <a href="child_maths.php">Mathematics</a>
  <a href="child_sinhala.php">Sinhala</a>
  <a href="child_eng.php">English</a>
  <a href="child_aes.php">Aesthetic</a>
 
  <a href="child_quiz1.php">Quiz</a>
  <a href="child_profile.php">Profile</a>
  
  <a href="logout.php?logout=true">Logout</a>
   
  </div>
   
        <h1 class="title" align="center">English</h1> <br>
        <div class="topnav">
          <!-- <img src="hat.png" align="left" height="80px" width="80px" class="hat"> -->
           <p class="paragraph"  align="center"><i>"One language sets you in a corridor for life.<br> Two languages open every door along the way."</i>

            <br> -Franck Smith-</p>
           
         </div>
            
        
            

<div class="imgbox"> 
  <a href="teacher_profile.php">  
    <button class="teacher_button">Meet Your Teacher</button></a><br>  <br>  <br>  <br>  <br>  
    <img class="center-fit" src='images/ebg.png'>
   <div class="container1">
    <div class="subnav1">
        <p>Vocab & Letters</p><br><br>
        <a href="child_e2.php">
        <button class="btn2">Start</button></a>
 
     </div>
     <!-- <div class="subnav1">
      <p>Grammar</p><br><br>
     
      <button class="btn2">Start</button>

   </div> -->
  
   <div class="subnav1">
    <p>Comprehension</p><br><br>
    <a href="child_e1.php">
    <button class="btn2">Start</button></a>

 </div>
 <br>
 <div class="subnav2">
  <p>Writing</p><br><br>
 
  <button class="btn2">Start</button>

</div>
<div class="subnav3">
<p>Reading</p><br><br>

<button class="btn2">Start</button>

</div>
     
   </div>
</div>
<br><br><br>
<!-- <hr style="color: blue; ">            -->
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>           


    </body>
    </html>
     
    