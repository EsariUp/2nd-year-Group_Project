<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM members WHERE id = 47";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
       
        while($row = mysqli_fetch_array($result)){
           
            $id= $row['id'];
            $first_name= $row['first_name'];
            $last_name= $row['last_name'];
            $email= $row['email'];
              
              
                // echo "<td>" . $row['last_name'] . "</td>";
                // echo "<td>" . $row['email'] . "</td>";
           
            echo $id;
            echo $email;
            echo $first_name;
            echo $last_name;
        }
       
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>