-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2021 at 08:52 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `gid` char(5) NOT NULL,
  `g_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`gid`, `g_name`) VALUES
('G1', 'Grade 1'),
('G2', 'Grade 2'),
('G3', 'Grade 3'),
('G4', 'Grade 4'),
('G5', 'Grade 5');

-- --------------------------------------------------------

--
-- Table structure for table `grade_teacher`
--

CREATE TABLE `grade_teacher` (
  `teacher_id` int(11) NOT NULL,
  `gid` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL DEFAULT '0',
  `last_name` varchar(255) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `first_name`, `last_name`, `email`, `password`, `created_at`, `updated_at`, `type`) VALUES
(33, 'Esari', 'Vithana', 'esariupendri1997@gmail.com', '$2y$04$aOfzWy0Eg6w0fu1doT1Fh.LrX8W4fu76I6Y62ne7kxgRecNoiiukS', '2021-09-30 18:58:10', '2021-09-30 18:58:10', 'student'),
(34, 'Samadi', 'Bhagya', 'samadi@gmail.com', '$2y$04$oUy2Mk8wi1O3SCszQND2dOwbzXqYzGjJtmKkdGfCmvMRzltNOr8qa', '2021-09-30 19:21:37', '2021-09-30 19:21:37', 'student'),
(35, 'Samadi', 'fernando', 'buddhima12@gmail.com', '$2y$04$vimo83TbuCyAPMbVzodNleFsFf88kyx6LBV1gVNg0RrVFmnWlZY62', '2021-10-02 19:03:22', '2021-10-02 19:03:22', 'student'),
(36, 'Samadi', 'Bhagya', 'sam@gmail.com', '$2y$04$Eu.fzx21XNm7htwP0pif9.FCdpBSLoMwImwM2rKgswr9I8yg4TBMa', '2021-10-02 19:13:13', '2021-10-02 19:13:13', 'student'),
(37, 'Neeta', 'Perera', 'neeta@gmail.com', '$2y$04$raEAtGLAEwvQC8jCOCP5R.JjBKt8NXq/e.EM.m1m7R.QiT/A/FUxC', '2021-10-03 05:59:19', '2021-10-03 05:59:19', 'student'),
(38, 'Jane', 'Fernando', 'jane@gmail.com', '$2y$04$gy98a7fVPyciyBpchS22Yu61JdsZtMcqDPlV91gzTAccTXW0v0CXW', '2021-10-03 06:06:59', '2021-10-03 06:06:59', 'student'),
(39, 'Senuli', 'Perera', 'piyumi@gmail.com', '$2y$04$DFIjS7Xi78KqlbeoI2wgwOtJdItSOWLb3TYaSTKqsAVrIphtDdytm', '2021-10-03 06:25:12', '2021-10-03 06:25:12', 'student'),
(40, 'Hashani', 'Gunarathna', 'hashani@gmail.com', '$2y$04$hRNGYFr.05rWxJ6u6nIuX.FswSqnWLkqBYyKC/ZoNLXV.52/ccoRW', '2021-10-03 06:38:32', '2021-10-03 06:38:32', 'student'),
(41, 'Shaini', 'Perera', 'shaini@gmail.com', '$2y$04$0TC6oOMtxGqgLcsJd2fWGuLVSagpngVlJ9xiMZiHCuZd.PUp.Ffcm', '2021-10-03 09:40:52', '2021-10-03 09:40:52', 'student'),
(42, 'Shalini', 'Perera', 'shalini@gmail.com', '$2y$04$ZPVixpgIXrBLQhMoOOIddO2lG9Ajk/.d3xPZzVF5ydCrD/Ak7Brl.', '2021-10-03 09:45:55', '2021-10-03 09:45:55', 'student'),
(43, 'Anne', 'Thisera', 'anne@gmail.com', '$2y$04$zHU04VtAZ/rzVA1rvWngjOM5eiahZp4nslRyQn0jQrJiJxIebzxui', '2021-10-03 09:52:32', '2021-10-03 09:52:32', 'student'),
(44, 'Anne', 'Thisera', 'anny@gmail.com', '$2y$04$fZFXaZpB6KEiE0wXtx56tejetonWGwj0QRHAelJIrY3/MAOOoufk2', '2021-10-03 09:53:46', '2021-10-03 09:53:46', 'student'),
(45, 'Nishani', 'Pathirana', 'nish@gmail.com', '$2y$04$bG1K9Uinq.OZp10mGXiOuuRg69nDz6.TiUBZvlXThir.ySEbbs7xa', '2021-10-03 18:59:00', '2021-10-03 18:59:00', 'student'),
(46, 'Harry', 'Perera', 'har@gmail.com', '$2y$04$BNJhaxMFIoiWqWBBS8lu6.nV3FnrzZKi2lai5FKm7cxznzACz8Pbq', '2021-10-05 10:03:04', '2021-10-05 10:03:04', 'student'),
(47, 'tina', 'yong', 'tina@gmail.com', '$2y$04$aE0aQn593I0nFuuWh7hzQuQJSqz0yXJXj9eX1pdQc8eEvdvHzXPOO', '2021-10-08 17:45:53', '2021-10-08 17:45:53', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `qqid` int(11) NOT NULL,
  `qid` char(5) NOT NULL,
  `q_desc` varchar(1000) NOT NULL,
  `op1` varchar(500) NOT NULL,
  `op2` varchar(500) NOT NULL,
  `op3` varchar(500) NOT NULL,
  `ans` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `quizz`
--

CREATE TABLE `quizz` (
  `qid` char(5) NOT NULL,
  `sid` char(5) NOT NULL,
  `gid` char(5) NOT NULL,
  `uid` char(5) NOT NULL,
  `q_title` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `uploaded_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `g_name` varchar(100) DEFAULT NULL,
  `g_mobile` char(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `g_name`, `g_mobile`, `dob`, `updated_at`) VALUES
(33, NULL, NULL, NULL, NULL),
(40, 'Saduni ', '0112455455', '2008-08-06', '2021-10-05 10:10:36'),
(44, 'Nishani ', '0112455455', '0000-00-00', NULL),
(45, 'Vimal', '0112455455', '2021-01-16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sid` char(5) NOT NULL,
  `s_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sid`, `s_title`) VALUES
('S1', 'MATHEMATICS');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `NIC` varchar(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `mobile` char(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `NIC`, `status`, `mobile`, `updated_at`) VALUES
(47, NULL, 'pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_qualification`
--

CREATE TABLE `teacher_qualification` (
  `teacher_id` int(11) NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `q_proof` mediumblob DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_qualification`
--

INSERT INTO `teacher_qualification` (`teacher_id`, `qualification`, `q_proof`, `updated_at`) VALUES
(47, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `uid` char(5) NOT NULL,
  `sid` char(5) NOT NULL,
  `u_title` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`uid`, `sid`, `u_title`) VALUES
('U1', 'S1', 'Numbers'),
('U2', 'S1', 'Addition'),
('U3', 'S1', 'Subtraction'),
('U4', 'S1', 'Multiplication');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `grade_teacher`
--
ALTER TABLE `grade_teacher`
  ADD PRIMARY KEY (`teacher_id`,`gid`),
  ADD KEY `gid` (`gid`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`qqid`,`qid`),
  ADD KEY `qid` (`qid`);

--
-- Indexes for table `quizz`
--
ALTER TABLE `quizz`
  ADD PRIMARY KEY (`qid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `gid` (`gid`),
  ADD KEY `quizz_ibfk_4` (`teacher_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sid`) USING BTREE;

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `NIC` (`NIC`);

--
-- Indexes for table `teacher_qualification`
--
ALTER TABLE `teacher_qualification`
  ADD PRIMARY KEY (`teacher_id`,`qualification`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`uid`,`sid`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `grade_teacher`
--
ALTER TABLE `grade_teacher`
  ADD CONSTRAINT `grade_teacher_ibfk_1` FOREIGN KEY (`gid`) REFERENCES `grade` (`gid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `grade_teacher_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`qid`) REFERENCES `quizz` (`qid`);

--
-- Constraints for table `quizz`
--
ALTER TABLE `quizz`
  ADD CONSTRAINT `quizz_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `unit` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quizz_ibfk_2` FOREIGN KEY (`sid`) REFERENCES `subject` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quizz_ibfk_3` FOREIGN KEY (`gid`) REFERENCES `grade` (`gid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quizz_ibfk_4` FOREIGN KEY (`teacher_id`) REFERENCES `members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `members` (`id`);

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `members` (`id`);

--
-- Constraints for table `teacher_qualification`
--
ALTER TABLE `teacher_qualification`
  ADD CONSTRAINT `teacher_qualification_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `members` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
