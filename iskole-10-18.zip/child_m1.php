<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_m1.css"/>
    <title>Quiz2</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_maths.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> Maths-PDFs
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
            <!-- <iframe class="video"  src="https://www.youtube.com/
            embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
             allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
            gyroscope; picture-in-picture" allowfullscreen></iframe> -->
            <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
            <iframe src="images/Numbers.pdf#toolbar=0" class="pdf" >
    </iframe>
         <br> <br>
          <button class="namebutton"><span>
           Identification of Numbers
            
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <!-- <iframe class="video"  src="https://www.youtube.com/
          embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
           allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
          gyroscope; picture-in-picture" allowfullscreen></iframe> -->
          <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
          <iframe src="images/Addition.pdf#toolbar=0" class="pdf" >
  </iframe>
       <br> <br>
        <button class="namebutton"><span>
          Addition 
          
        </span>
         
        </button>
       
      </div>
      <div class="button1">
        <!-- <iframe class="video"  src="https://www.youtube.com/
        embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
         allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
        gyroscope; picture-in-picture" allowfullscreen></iframe> -->
        <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
        <iframe src="images/Subtraction.pdf#toolbar=0" class="pdf" >
</iframe>
     <br> <br>
      <button class="namebutton"><span>
      Subtraction
        
      </span>
       
      </button>
     
    </div>
 <br><br><br><br> <br>
 <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/Multiplication.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton"><span>
  Multiplication
  
</span>
 
</button>

</div>  <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/Division.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton"><span>
  Division
</span>
 
</button>

</div>  <div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <!-- <img src="maths.jpg" height="100px" width="100px"></img> -->
  <iframe src="images/Shapes.pdf#toolbar=0" class="pdf" >
</iframe>
<br> <br>
<button class="namebutton"><span>
  Shapes
  
</span>
 
</button>

</div>
    </div>
    <br>  
    
    
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>