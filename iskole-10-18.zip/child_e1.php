<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_e1.css"/>
    <title>Quiz2</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_eng.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> Shapes-Maths
          </h1>
      
       
          <br>  <br>  <br>  <br>
      <div class="chapterButtons">
        <div class="button1">
            <!-- <iframe class="video"  src="https://www.youtube.com/
            embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
             allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
            gyroscope; picture-in-picture" allowfullscreen></iframe> -->
            <iframe src="https://youtube.com/embed/dmhtjrVJS7c" class="video" frameborder="0"></iframe>
         <br> <br> <br>
          <button class="namebutton"><span>
            Shapes - Part I
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <!-- <iframe class="video"  src="https://www.youtube.com/
          embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
           allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
          gyroscope; picture-in-picture" allowfullscreen></iframe> -->
          <iframe src="https://youtube.com/embed/BY5TkXOk2kQ"  class="video" frameborder="0"></iframe>
       <br> <br> <br>
        <button class="namebutton"><span>
          Shapes - Part II
        </span>
         
        </button>
        
      </div>
      <div class="button1">
        <!-- <iframe class="video"  src="https://www.youtube.com/
        embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
         allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
        gyroscope; picture-in-picture" allowfullscreen></iframe> -->
        <iframe src="https://youtube.com/embed/K5Uwcag7QaE"  class="video" frameborder="0"></iframe>
     <br> <br> <br>
      <button class="namebutton"><span>
        Shapes - Part III
      </span>
       
      </button>
      
    </div>
    <br> <br> <br>

    <div class="button1">
      <!-- <iframe class="video"  src="https://www.youtube.com/
      embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
       allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
      gyroscope; picture-in-picture" allowfullscreen></iframe> -->
      <iframe src="https://youtube.com/embed/2fvCOwGIcZA"  class="video" frameborder="0"></iframe>
   <br> <br> <br>
    <button class="namebutton"><span>
      Shapes - Part IV
    </span>
     
    </button>
    
  </div>
  <div class="button1">
    <!-- <iframe class="video"  src="https://www.youtube.com/
    embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
     allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
    gyroscope; picture-in-picture" allowfullscreen></iframe> -->
    <iframe src="https://youtube.com/embed/4tkRwMHu9NQ"  class="video" frameborder="0"></iframe>
 <br> <br> <br>
  <button class="namebutton"><span>
    Shapes - Part V
  </span>
   
  </button>
  
</div>
<div class="button1">
  <!-- <iframe class="video"  src="https://www.youtube.com/
  embed/qXXknB5bePU" title="YouTube video player" frameborder="0"
   allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
  gyroscope; picture-in-picture" allowfullscreen></iframe> -->
  <iframe src="https://youtube.com/embed/AsQ_uJDBrIU"  class="video" frameborder="0"></iframe>
<br> <br> <br>
<button class="namebutton"><span>
  Shapes - Part VI
</span>
 
</button>

</div>
      <!-- <div class="chapterButtons">
        <input type="button2" class="button2 N" value="Nouns">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 Aj" value="Adjectives">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 V" value="Verbs">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 Si" value="Sentences">
        <input type="button3" class="button3" value="5 Questions">
    </div>
    <div class="roundbuttons">

        <input type="button4" class="button4 N1" value="N"><br><br>
        <input type="button4" class="button4 A2" value="A"><br><br><br>
        <input type="button4" class="button4 V3" value="V"><br><br>
        <input type="button4" class="button4 S4" value="S">
       
    </div> -->
    <!-- <div class="image">
        <img src="english.png" height="200px"/>
    </div> -->
    </div>
    <br>  
    
    
   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>