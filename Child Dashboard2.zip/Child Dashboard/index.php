<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: welcome.php");
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}

?>


<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in</title>
    <link rel="stylesheet" href="style.css" >
</head>
<body>      
    <div class="nav-container">
        
        <nav>
            <button class="btnhome" align="left" >Home</button>
            
                <img src="login-images/logo.jpg" align="right" >
           

        </nav>

    
        <div class="wrapper">
                <div class="container1">
                    <form>
                       
                        <label for="username">Username:</label><br><br>
                        <input type="text" id="username" name="username" placeholder="Username"><br><br><br>
                        <label for="pwd">Password:</label><br><br>
                        <input type="password" id="pwd" name="pwd" placeholder="password">
                    </form><br>
                    <div>
                    <a class="forgot" href="#">Forgot password?</a><br>
                    </div><br>
					<div class="input-group">
				<button name="submit" class="btn">Login</button>
			</div>  
                   
                    <br>
                    <div>
					<p class="login-register-text">Not registered yet? <a href="register.php">Create an account</a>.</p>
                    </div> 
            
                    <div class="login-image">
                    <img src="login-images/child-true.jpg" alt=""/>
                    </div>
                </div> 
        </div>
            <button class="btn2">
                <a href="#"><img src="login-images/back-arrow2.png"/></a>
            </button>
            

    
    <script src="login.js"></script>

</body>
</html> -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link rel="stylesheet" type="text/css" href="logins.css"> 

	<title>Login Form - Pure Coding</title>
</head>
<body>
<div class="nav-container">
        
        <nav>
           
            
                <img src="login-images/logo.jpg" align="right" >
           

        </nav>
<div class="wrapper">
<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			
			<div class="input-group">
				<input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			
			<div class="input-group">
				<button name="submit" class="btn">Login</button>
			</div>
			<p class="login-register-text">Don't have an account? <a href="register.php">Register Here</a>.</p>
		</form>
		<div class="login-image">
                    <img src="login-images/child-true.jpg" alt=""/>
                    </div>
</div>
	
	</div>
</body>
</html> 