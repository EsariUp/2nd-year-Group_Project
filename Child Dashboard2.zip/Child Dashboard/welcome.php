<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <?php echo "<h1>Welcome " . $_SESSION['username'] . "</h1>"; ?>
    <a href="logout.php">Logout</a>
</body>
</html> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="welcome.css"/>
    <title>Document</title>
</head>
<body>
    
    <div class="sidebar">
        
        <button class="btn1"><img src="back.png" height="90px" width="70px">
            
        </button>
        <img src="eskole.png" align="right" height="80px" width="80px">
        
       <br><br><br><br><br><br><br><br>
       <ul>
        <li><a href="#mycourse"><img src="Mycourse.png" height="40px">My Course</a></li><br><br><br><br>
        <li><a href="#quiz"><img src="Quiz.png" height="35px">Quiz</a></li><br><br><br><br>
        <li><a href="#payment"><img src="payment.png" height="50px">Payment</a></li><br><br><br><br>
        <li><a href="logout.php"><img src="logout.png" height="50px">Logout</a></li><br>
        
      </ul>
        <img src="sidebar.png" width="200px">
    </div>
     <div class="main">
        <nav>
            <div class="nav-container5"> 
                
            </div>
             
            </nav>
        
         <h2>
         
           </button><img src="profile.png"/><?php echo "Welcome " . $_SESSION['username'] . ""; ?> <img src="hello.png" height="35px"/>
           
        </h2>
        
        <nav>
            <div class="nav-container3"> 
                <p>Calendar</p><br><br>
                <img src="cal1.png" height="100px" width="150px"/>
                <button class="btn3">View</button>
            </div>
             
            <div class="nav-container3"> 
                <p>Exhibition</p><br><br>
               <img src="exhibition.png"
                    height="100px" width="150px"/><br><br>
                <button class="btn3">View</button></h3>
            </div>
            <div class="nav-container3"> 
                <p>My Drawing Board</p>
                <img src="draw.png"
                height="100px" width="150px"/>
                <button class="btn3">Start</button>
            </div>
            </nav>
        
        <nav>
            <div class="nav-container1">
                
                <span class="multicolortext">Let's have a chat</span><br><br>
                <img src="chat.png" height="100px" width="100px"/> 
                <button class="btn4">Join</button>
            </div>
             
            <div class="nav-container1"> 
                
                <span class="multicolortext">Your Badges</span><br><br>
                <img src="dashboard.png" height="100px" width="200px"/>
                <button class="btn4">Join</button>
            </div>

            <nav>
                <div class="nav-container4"> 
                    
                </div>
                 
                </nav>

     </div> 
    
    </div>
       
  
     
        
 
</body>
</html>