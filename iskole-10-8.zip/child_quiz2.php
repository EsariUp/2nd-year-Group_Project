<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="child_quiz2.css"/>
    <title>Quiz2</title>
</head>
<body>
    <div class="nav-container">
        <div class="logo">
          <img src="images/logo.jpg" align="right" height="80px" width="80px" >
      </div> 
      <a href="child_quiz1.php"> <button class="btn1"><img src="images/back.png" height="80px" width="60px">  </button></a>
       
             
              <nav>
  
           
                <div class="icon-bar">
                  <a class="active" href="#"><img src="images/home.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/profile1.png" height="30px" width="30px"/></a> 
                  <a href="#"><img src="images/notifications.png" height="30px" width="30px"/></a> 
                 
                </div>  
              </nav>
        
          
          <h1 class="title" align="center"> "Don't stress, do your best, forget the 
            rest, and all the best."
          </h1>
      
        <nav>
          <a href="child_quiz1.php">
            <input type="button" class="button " value="Grade"></a>
         
          <input type="button" class="button active" value="Chapter">
          
          <input type="button" class="button" value="Score">
          
          
      </nav>
      <div class="chapterNames">
        <h3>My Chapters</h3>
        <input type="button" class="button M " value="Maths">
        <input type="button" class="button E active" value="English">
        <input type="button" class="button S" value="Sinhala">
        <input type="button" class="button A" value="Aesthetic">
      </div>
      <div class="chapterButtons">
        <div class="button1">
          <b>Nouns</b> <br> <p style="color:rgb(126, 126, 126)"> 
            <small><u>5 Questions</u><small></p>
         
          <button class="namebutton"><span>
            Quiz
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <b>Verbs</b> <br> <p style="color:rgb(126, 126, 126)"> 
            <small><u>5 Questions</u><small></p>
         <a href="child_quiz3.php"> <button class="namebutton"><span>
          Quiz
        </span>
         
        </button>
       </a>
         
        </div>
        <div class="button1">
          <b>Adjectives</b> <br> <p style="color:rgb(126, 126, 126)"> 
            <small><u>5 Questions</u><small></p>
         
          <button class="namebutton"><span>
            Quiz
          </span>
           
          </button>
         
        </div>
        <div class="button1">
          <b>Sentences</b> <br> <p style="color:rgb(126, 126, 126)"> 
            <small><u>5 Questions</u><small></p>
         
          <button class="namebutton"><span>
            Quiz
          </span>
           
          </button>
         
        </div>
      </div>
      <!-- <div class="chapterButtons">
        <input type="button2" class="button2 N" value="Nouns">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 Aj" value="Adjectives">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 V" value="Verbs">
        <input type="button3" class="button3" value="5 Questions"><br><br>
        <input type="button2" class="button2 Si" value="Sentences">
        <input type="button3" class="button3" value="5 Questions">
    </div>
    <div class="roundbuttons">

        <input type="button4" class="button4 N1" value="N"><br><br>
        <input type="button4" class="button4 A2" value="A"><br><br><br>
        <input type="button4" class="button4 V3" value="V"><br><br>
        <input type="button4" class="button4 S4" value="S">
       
    </div> -->
    <!-- <div class="image">
        <img src="english.png" height="200px"/>
    </div> -->
    </div>
    <br>  <br> <br>  <br> <br>  <br> <br>  <br> <br>  
    <br>  <br> <br>  <br> <br>  <br> <br>  <br>
    <br>  <br> <br>  <br> <br>   <br> <br>  <br> 

   
    <hr style="color: blue; ">           
<div class="footer-main">

<div class="footer">

<footer>&copy; 2021    ALL RIGHTS RESERVED BY 361°</footer>
</div> 
</div>   
</body>
</html>