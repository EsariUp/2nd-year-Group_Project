<?php
session_start();
?>
<html>
<head>
<title>User Login</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
<tr class="tableheader">
<td align="center">User Dashboard</td>
</tr>
<tr class="tablerow">
<td>
<?php

if($_SESSION["first_name"]) {
   $sql= "S"
?>
Welcome <?php echo $_SESSION['first_name'] ; ?>.
Click here to <a href="logout.php" tite="Logout">Logout.<br /> <a href="profile.php" tite="profile"> see my profile
<?php
}
?>
</td>
</tr>
</body></html>
